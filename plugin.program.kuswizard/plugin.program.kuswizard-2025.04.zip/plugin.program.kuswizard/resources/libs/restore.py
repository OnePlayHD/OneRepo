import xbmc
import xbmcgui
import xbmcvfs
import os
import six

if six.PY3:
    import zipfile
elif six.PY2:
    from resources.libs import zipfile

from resources.libs.common import logging
from resources.libs.common import tools
from resources.libs.common.config import CONFIG

def binaries():
    dialog = xbmcgui.Dialog()

    binarytxt = os.path.join(CONFIG.USERDATA, 'build_binaries.txt')

    if os.path.exists(binarytxt):
        binaryids = tools.read_from_file(binarytxt).split(',')

        logging.log("[Binary Detection] Reinstalling Eligible Binary Addons")
        dialog.ok(CONFIG.ADDONTITLE,'Der installierte Build enthält plattformspezifische Addons, die nun automatisch installiert werden. Während dieses Prozesses können eine Reihe von Dialogen auftauchen. Das Abbrechen dieser kann dazu führen, dass der installierte Build nicht richtig funktioniert.'.format(CONFIG.COLOR2))
    else:
        logging.log("[Binary Detection] No Eligible Binary Addons to Reinstall")
        return True

    success = []
    fail = []

    if len(binaryids) == 0:
        logging.log('No addons selected for installation.')
        return

    from resources.libs.gui import addon_menu

    for addonid in binaryids:
        if addon_menu.install_from_kodi(addonid):
            logging.log('{0} install succeeded.'.format(addonid))
            success.append(addonid)
        else:
            logging.log('{0} install failed.'.format(addonid))
            fail.append(addonid)

    if not fail:
        dialog.ok(CONFIG.ADDONTITLE, 'Die plattformspezifische Addons wurden alle erfolgreich installiert.')
        os.remove(binarytxt)
        return True
    else:
        dialog.ok(CONFIG.ADDONTITLE, 'Folgende plattformspezifische Addons konnten nicht installiert werden:\n{0}'.format(', '.join(fail)))
        return False

class Restore:
    def __init__(self, external=False):
        tools.ensure_folders()

        self.external = external
        self.dialog = xbmcgui.Dialog()
        self.progress_dialog = xbmcgui.DialogProgress()

    def _prompt_for_wipe(self):
        wipe = self.dialog.yesno(CONFIG.ADDONTITLE,"Willst du Kodi auf Werkseinstellung zurücksetzen,".format(CONFIG.COLOR2) + '\n' + "bevor du das Backup installierst?".format('local' if not self.external else 'external'), nolabel='[COLORred]NEIN[/COLOR]', yeslabel='[COLORlime]JA[/COLOR]')

        if wipe:
            from resources.libs import install
            install.wipe()

    def _from_file(self, file, loc):
        from resources.libs import db
        from resources.libs import extract

        display = os.path.split(file)
        filename = display[1]
        packages = os.path.join(CONFIG.PACKAGES, filename)

        if not self.external:
            try:
                zipfile.ZipFile(file, 'r', allowZip64=True)
            except zipfile.BadZipFile as e:
                from resources.libs.common import logging
                logging.log(e, level=xbmc.LOGERROR)
                self.progress_dialog.update(0, 'Die Zip-Datei kann aus dem aktuellen Verzeichnis nicht gelesen werden.'.format(CONFIG.COLOR2) + '\n' + 'Kopiere Dateien nach Packages...')
                xbmcvfs.copy(file, packages)
                file = xbmcvfs.translatePath(packages)
                self.progress_dialog.update(0, '\n' + 'Kopiere Dateien nach Packages: Abgeschlossen')
                zipfile.ZipFile(file, 'r', allowZip64=True)
        else:
            from resources.libs.downloader import Downloader
            Downloader().download(file, packages)

        self._prompt_for_wipe()

        self.progress_dialog.update(0, 'Installiere Backup.' + '\n' + 'Bitte warten...')
        percent, errors, error = extract.all(file, loc)
        self._view_errors(percent, errors, error, file)

        CONFIG.set_setting('installed', 'true')
        CONFIG.set_setting('extract', percent)
        CONFIG.set_setting('errors', errors)

        if self.external:
            try:
                os.remove(file)
            except:
                pass

        db.force_check_updates(over=True)

        tools.kill_kodi(msg='Um Änderungen zu speichern, muss Kodi beendet werden. Willst du fortfahren?'.format(CONFIG.COLOR2))

    def _view_errors(self, percent, errors, error, file):
        if int(errors) >= 1:
            if self.dialog.yesno(CONFIG.ADDONTITLE, '[COLORdeepskyblue]{2}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1, file) + '\n' + 'Abgeschlossen: [COLORdeepskyblue]{1}{2}[/COLOR] [Fehler: [COLORdeepskyblue]{4}[/COLOR]]'.format(CONFIG.COLOR1, percent, '%',CONFIG.COLOR1, errors) + '\n' + 'Willst du dir die Fehler ansehen?', nolabel='[COLORred]NEIN[/COLOR]', yeslabel='[COLORlime]JA[/COLOR]'):

                from resources.libs.gui import window
                window.show_text_box("Fehler bei der Installation", error.replace('\t', ''))

    def choose(self, location):
        from resources.libs import skin

        skin.look_and_feel_data('restore')
        external = 'Externes Backup' if self.external else 'Lokales Backup'

        file = self.dialog.browseSingle(1, '{0}: Wähle Backup zum installieren aus.'.format(CONFIG.ADDONTITLE), '' if self.external else 'files', mask='.zip', useThumbs=True, defaultt=None if self.external else CONFIG.MYBUILDS)

        if not file.endswith('.zip'):
            logging.log_notify(CONFIG.ADDONTITLE,"{1} installieren: [COLORdeepskyblue]Abgebrochen![/COLOR]".format(CONFIG.COLOR2, external))
            return

        if self.external:
            from resources.libs.common import tools
            response = tools.open_url(file, check=True)

            if not response:
                logging.log_notify(CONFIG.ADDONTITLE,"Installation: [COLORred]Fehler![/COLOR]".format(CONFIG.COLOR2))
                return

        skin.skin_to_default("Restore")
        self.progress_dialog.create(CONFIG.ADDONTITLE, 'Installiere [COLORdeepskyblue]{1}[/COLOR] Backup'.format(CONFIG.COLOR2, external) + '\n' + 'Bitte warten...')

        self._from_file(file, location)

def restore(action, external=False):
    cls = Restore(external)

    if action == 'build':
        cls.choose(CONFIG.HOME)
    elif action in ['gui', 'addonpack']:
        cls.choose(CONFIG.USERDATA)
    elif action == 'addondata':
        cls.choose(CONFIG.ADDON_DATA)
    elif action == 'binaries':
        binaries()

##############################################################
#                                                            #
#  Copyright (C) 2025 SGKodi / Kodi Unlimited Support Group  #
#                                                            #
##############################################################		