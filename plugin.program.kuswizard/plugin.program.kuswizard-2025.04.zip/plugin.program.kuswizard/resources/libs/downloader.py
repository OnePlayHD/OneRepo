import xbmc
import xbmcgui
import requests
import sys
import os
import time

from resources.libs.common import logging
from resources.libs.common import tools
from resources.libs.common.config import CONFIG

class Downloader:
    def __init__(self):
        self.dialog = xbmcgui.Dialog()
        self.progress_dialog = xbmcgui.DialogProgress()

    def download(self, url, dest):
        self.progress_dialog.create(CONFIG.ADDONTITLE, "Lade Daten")
        self.progress_dialog.update(0)
        
        path = os.path.split(dest)[0]
        if not os.path.exists(path):
            os.makedirs(path)
        with open(dest, 'wb') as f:
            response = tools.open_url(url, stream=True)
            
            if not response:
                logging.log_notify(CONFIG.ADDONTITLE,'Build Installation: [COLORred]Ungültige Zip Url![/COLOR]'.format(CONFIG.COLOR2))
                return
            else:
                total = response.headers.get('content-length')

            if total is None:
                f.write(response.content)
            else:
                downloaded = 0
                total = int(total)
                start_time = time.time()
                mb = 1024*1024
                
                for chunk in response.iter_content(chunk_size=max(int(total/512), mb)):
                    downloaded += len(chunk)
                    f.write(chunk)
                    
                    done = int(100 * downloaded / total)
                    kbps_speed = downloaded / (time.time() - start_time)
                    
                    if kbps_speed > 0 and not done >= 100:
                        eta = (total - downloaded) / kbps_speed
                    else:
                        eta = 0
                    
                    kbps_speed = kbps_speed / 1024
                    type_speed = 'KB'
                    
                    if kbps_speed >= 1024:
                        kbps_speed = kbps_speed / 1024
                        type_speed = 'MB'
                        
                    currently_downloaded = 'Buildgröße gezippt: [COLORdeepskyblue]%.02f[/COLOR] MB[CR]Heruntergeladen: [COLORdeepskyblue]%.02f[/COLOR] MB' % (total / mb, downloaded / mb)
                    speed = 'Downloadgeschwindigkeit: [COLORdeepskyblue]%.02f [/COLOR]%s/s ' % (kbps_speed, type_speed)
                    div = divmod(eta, 60)
                    speed += '[CR]Verbleibende Zeit: [COLORdeepskyblue]%02d:%02d[/COLOR]' % (div[0], div[1])
                    
                    self.progress_dialog.update(done, '\n' + str(currently_downloaded) + '\n' + str(speed)) 

##############################################################
#                                                            #
#  Copyright (C) 2025 SGKodi / Kodi Unlimited Support Group  #
#                                                            #
##############################################################