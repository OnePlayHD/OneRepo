# -*- coding: utf-8 -*-
import six
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import sys
import re
import os
try:
    from urllib.parse import quote, quote_plus, urlencode #python 3
except ImportError:     
    from urllib import quote, quote_plus, urlencode #python 2
try:
    import json
except:
    import simplejson as json 
    

plugin = sys.argv[0]
handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
if six.PY3:
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    home = xbmcvfs.translatePath(addon.getAddonInfo('path'))
else:
    profile = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
    home = xbmc.translatePath(addon.getAddonInfo('path')).decode('utf-8')    
fanart_default = os.path.join(home, 'fanart.jpg')
icone_mp3 = os.path.join(home, 'icon_mp3.jpg')
favorites = os.path.join(profile, 'favorites.dat')
if os.path.exists(favorites)==True:
    FAV = open(favorites).read()
else:
    FAV = []
api = 'https://slider.kz/vk_auth.php'

def get_url(params):
    url = '%s?%s'%(plugin, urlencode(params))
    return url

def notify(message,name=False,iconimage=False,timeShown=5000):
    if name and iconimage:
        if six.PY3:
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (name, message, timeShown, iconimage))
        else:
            xbmc.executebuiltin('XBMC.Notification(%s, %s, %d, %s)' % (name, message, timeShown, iconimage))
    else:
        if six.PY3:
            xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (addonname, message, timeShown, icon))
        else:
            xbmc.executebuiltin('XBMC.Notification(%s, %s, %d, %s)' % (addonname, message, timeShown, icon))


def addDir(name,params,iconimage,fanart,description,folder=True,favorite=False,download=False):
    url = get_url(params)
    try:
        playable = str(params.get("playable"))
    except: 
        playable = 'false'
    try:
        download_url = params.get("url")
    except:
        donwload_url = 'false'
    if six.PY3:
        li=xbmcgui.ListItem(name)
        if folder:
            li.setArt({"icon": "DefaultFolder.png", "thumb": iconimage})
        else:
            li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    else:
        li = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    if playable == 'true':
        li.setProperty('IsPlayable', 'true')
    li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    if fanart > '':
        li.setProperty('fanart_image', fanart)
    else:
        li.setProperty('fanart_image', fanart_default)
    if favorite == True or download == True:
        contextMenu = []
        if download == True:
            if not download_url == 'false':
                contextMenu.append(('BAIXAR MÚSICA','RunPlugin(%s?action=download&name=%s&url=%s)'%(plugin, quote_plus(name), quote_plus(download_url))))
        if favorite == True:
            try:
                name_fav = json.dumps(name.decode('utf-8'))
            except:
                try:
                    name_fav = name.decode('utf-8')
                except:
                    name_fav = name
            if name_fav in FAV:
                contextMenu.append(('REMOVER DA MINHA PLAYLIST','RunPlugin(%s?action=removeFavorites&name=%s)'%(plugin, quote_plus(name))))
            else:                
                contextMenu.append(('ADICIONAR A MINHA PLAYLIST','RunPlugin(%s?action=addFavorite&name=%s&url=%s&iconimage=%s&fanart=%sdescription=%s)'%(plugin, quote_plus(name), quote_plus(download_url), quote_plus(iconimage), quote_plus(fanart), quote_plus(description))))
        try:
            li.addContextMenuItems(contextMenu)
        except:
            pass
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=folder)

def play_mp3(name,url,iconimage,playable):
    li = xbmcgui.ListItem(name, path=url)
    li.setArt({"icon": iconimage, "thumb": iconimage})
    li.setInfo(type='video', infoLabels={'Title': name, 'plot': '' })
    li.setProperty('fanart_image', fanart_default)
    if playable == 'true':
        xbmcplugin.setResolvedUrl(handle, True, li)
    else:
        xbmc.Player().play(item=url, listitem=li)

def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string 

def browser(url):
    try:
        from urllib.request import Request, urlopen, URLError  # Python 3
    except ImportError:
        from urllib2 import Request, urlopen, URLError  # Python 2
    try:
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36')
        content = urlopen(req).read().decode('utf-8')
    except URLError as e:
        if hasattr(e, 'code'):
            xbmc.log('Slider Kz - Falha, código de erro %s'%str(e.code))
        elif hasattr(e, 'reason'):
            xbmc.log('Slider Kz - Falha, motivo %s'%str(e.reason))
        content = ''
    return content
    
def resolver(id, duration, tit_art, url, extra):
    url = url.replace('\/', '/')
    resolved = 'https://slider.kz/download/%s/%s/%s/%s.mp3?extra=%s'%(id,duration,url,quote(tit_art),extra)
    resolved = resolved+'|Referer=https://slider.kz/'
    return resolved

def show_list(pesquisa):
    xbmcplugin.setContent(handle, 'songs')
    url = '{}?q={}'.format(api,pesquisa)
    data = browser(url)
    lista = re.compile('{"id":"(.*?)","duration":(.*?),"tit_art":"(.*?)","url":"(.*?)","extra":"(.*?)"}').findall(data)
    count = 0
    for id, duration, tit_art, url, extra in lista:
        try:
            name = tit_art.encode('utf-8').decode('unicode_escape')
        except:
            name = tit_art
        count += 1
        name = str(count) + ' - ' + name
        resolved = resolver(id, duration, tit_art, url, extra)
        addDir(name.encode('utf-8', 'ignore'),{'action': 'play', 'name': name.encode('utf-8', 'ignore'), 'url': resolved, 'iconimage': icone_mp3, 'playable': 'false'},icone_mp3,'','Segure a tecla OK ou mantenha pressionado para exibir menu extra',folder=False,favorite=True,download=True)
    xbmcplugin.endOfDirectory(handle)
    
def search():
    vq = get_search_string(heading="Digite algo para pesquisar", message="")        
    if ( not vq ): return False, 0
    title = quote_plus(vq)
    show_list(title)           

def downloadMP3(name,url):
    if '.mp3' in name:
        file = name
    else:
        file = name+'.mp3'
    folder = xbmcgui.Dialog().browseSingle(0, 'Selecione um local para download', 'local', '', False, False)
    if os.path.isdir(folder):
        from resources.lib import downloader
        dest=os.path.join(folder, file)
        if 'Referer' in url:
            link = url.split('|Referer')[0]
        else:
            link = url
        try:
            downloader.download(link, file, dest)
        except:
            notify('Erro ao baixar, pesquise a musica novamente para renovar url') 

def getFavorites():
    try:
        try:
            items = json.loads(open(favorites).read())
        except:
            items = ''
        total = len(items)
        if int(total) > 0:
            xbmcplugin.setContent(handle, 'songs')
            for i in items:
                name = i[0]
                url = i[1]
                iconimage = i[2]
                fanart = i[3]
                description = i[4]
                addDir(name.encode('utf-8', 'ignore'),{'action': 'play', 'name': name.encode('utf-8', 'ignore'), 'url': url, 'iconimage': icone_mp3, 'playable': 'true'},icone_mp3,'','Segure a tecla OK ou mantenha pressionado para exibir menu extra',folder=False,favorite=True,download=True)
            xbmcplugin.endOfDirectory(handle,cacheToDisc=False)
        else:
            xbmcplugin.endOfDirectory(handle)
            #xbmcgui.Dialog().ok('[B][COLOR white]AVISO[/COLOR][/B]','Nenhuma música adicionada na Minha Playlist')                
    except:
        xbmcplugin.endOfDirectory(handle)

def addFavorite(name,url,iconimage,fanart,description):
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    favList = []
    if os.path.exists(favorites)==False:
        #addonID
        addon_data_path = profile
        if os.path.exists(addon_data_path)==False:
            os.mkdir(addon_data_path)
        xbmc.sleep(7)
        favList.append((name,url,iconimage,fanart,description))
        a = open(favorites, "w")
        a.write(json.dumps(favList))
        a.close()
        notify('Adicionado a Minha Playlist!',name,iconimage)
    else:
        a = open(favorites).read()
        data = json.loads(a)
        data.append((name,url,iconimage,fanart,description))
        b = open(favorites, "w")
        b.write(json.dumps(data))
        b.close()
        notify('Adicionado a Minha Playlist!',name,iconimage) 

def rmFavorite(name):
    data = json.loads(open(favorites).read())
    for index in range(len(data)):
        if data[index][0]==name:
            del data[index]
            b = open(favorites, "w")
            b.write(json.dumps(data))
            b.close()
            break
    notify('Removido da Minha Playlist!')
    if six.PY3:
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmc.executebuiltin('XBMC.Container.Refresh')
        
def clear_list():
    exists = os.path.isfile(favorites)
    if exists:
        if xbmcgui.Dialog().yesno(addonname, 'Deseja limpar Minha Playlist?'):
            try:
                os.remove(favorites)
            except:
                pass
            xbmcgui.Dialog().ok('Sucesso', '[B]Minha Playlist limpa com sucesso![/B]')        

def home(): 
    addDir('[B]Pesquisar[/B]',{'action': 'search'},'','','')
    addDir('[B]Minha Playlist[/B]',{'action': 'getFavorites'},'','','')
    addDir('[B]Limpar Playlist[/B]',{'action': 'clear'},'','','')
    xbmcplugin.endOfDirectory(handle)