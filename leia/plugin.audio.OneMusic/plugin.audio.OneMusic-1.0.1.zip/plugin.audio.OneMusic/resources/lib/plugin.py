# -*- coding: utf-8 -*-
import sys
try:
    from urllib.parse import urlparse, parse_qs, unquote_plus, urlencode #python 3
except ImportError:    
    from urlparse import urlparse, parse_qs #python 2
    from urllib import unquote_plus, urlencode
from resources.lib import items

   

def run():
    args = parse_qs(sys.argv[2][1:])
    action = args.get("action")
    name = args.get("name")
    url = args.get("url")
    iconimage = args.get("iconimage")
    fanart = args.get("fanart")
    description = args.get("description")
    playable = args.get("playable")
    if name:
        name = name[0]
    if url:
        url = url[0]
    if iconimage:
        iconimage = iconimage[0]
    else:
        iconimage = ''
    if fanart:
        fanart = fanart[0]
    else:
        fanart = ''
    if description:
        description = description[0]
    else:
        description = ''
    if playable:
        playable = playable[0]
    else:
        playable = 'false'
    if action == None:
        items.home()
    elif 'search' in action:
        items.search()
    elif 'play' in action:
        if name and url and playable:
            items.play_mp3(name,url,iconimage,playable)
    elif 'download' in action:
        if name and url:
            items.downloadMP3(name,url)
    elif 'addFavorite' in action:
        if name and url:
            items.addFavorite(name,url,iconimage,fanart,description)
    elif 'removeFavorites' in action:
        if name:
            items.rmFavorite(name)
    elif 'getFavorites' in action:
        items.getFavorites()
    elif 'clear' in action:
        items.clear_list()
        
    