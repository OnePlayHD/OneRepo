try:
    from libs.browser import request, UA #kodi
except:
    from browser import request, UA # vscode
from bs4 import BeautifulSoup
import re
try:
    import json
except:
    import simplejson as json
try:
    from urllib.parse import urlparse, parse_qs, quote_plus #python 3
except ImportError:    
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote_plus

homepage = 'https://www.mydoramas.com'
search_page = homepage + '/?s='

def index_page(url=None):
    if not url:
        url = homepage + '/'
    html = request.get_url(url)
    soup = BeautifulSoup(html, 'html.parser')
    div_videos = soup.find("div", {"id": "videos"})
    divs_box_videos = soup.find_all("div", {"class": "boxvideo"})
    lista_videos = []
    if divs_box_videos:
        for i in divs_box_videos:
            img = i.find("img").get("src") if i.find("img").get("src") else ''
            name = i.find("a", {"class": "titulo"}).text if i.find("a", {"class": "titulo"}) else i.find("a", {"class": "thumb"}).get("title")
            href = i.find("a", {"class": "titulo"}).get("href") if i.find("a", {"class": "titulo"}).get("href") else i.find("a", {"class": "thumb"}).get("href")
            category = i.find("span", {"class": "qualidade"}).text
            lista_videos.append((name,category,img,href))
    try:
        next = soup.find("a", {"rel": "next"}).get("href")
        if next:
            next_url = next
        else:
            next_url = False
    except:
        next_url = False
    return lista_videos, next_url

def seasons(url):
    html = request.get_url(url)
    soup = BeautifulSoup(html, 'html.parser')
    sinopse = soup.find("div", {"class": "sinopsee"})
    if sinopse:
        desc = sinopse.text
    else:
        desc = ''
    temps = soup.find_all("div", class_=lambda x: x and x.endswith('view'))
    if not temps:
        eps = soup.find("div", {"class": "eps"})
        if eps:
            movie = eps.find("a").get("data-href")
            if movie:
                movie_link = movie
            else:
                movie_link = False
        else:
            movie_link = False
    else:
        movie_link = False
    seasons = []
    if temps:
        count_season = 0
        for temp in temps:
            count_season += 1
            seasons.append(count_season)
    return seasons, desc, movie_link


def episodes(url,season):
    html = request.get_url(url)
    soup = BeautifulSoup(html, 'html.parser')
    temps = soup.find_all("div", class_=lambda x: x and x.endswith('view'))
    episodes = []
    if temps:
        count_season = 0
        for temp in temps:
            count_season += 1
            if int(season) == count_season:
                eps = temp.find_all("a")
                count_ep = 0
                for ep in eps:
                    count_ep += 1
                    href = ep.get("data-href")
                    #name = ep.text
                    episodes.append((count_ep,href))
    return episodes

def links(url):
    html = request.get_url(url)
    soup = BeautifulSoup(html, 'html.parser')
    itens = soup.find("div", {"class": "itens"})
    a = itens.find_all("a")
    options = []
    if a:
        count = 0
        for i in a:
            count += 1
            number = '0%s'%str(count) if count < 10 else str(count)
            href = 'https:' + i.get("data-href") if not 'http' in i.get("data-href") else i.get("data-href")
            if 'upstream' in href:
                name = 'SERVIDOR UPSTREAM'
            elif 'fembed' in href:
                name = 'SERVIDOR FEMBED (MAIS ESTABILIDADE)'
            elif 'vidlox' in href:
                name = 'SERVIDOR VIDLOX'
            else:
                name = 'SERVIDOR %s'%number
            options.append((name,href))
    return options

def find_link(url):
    if 'mydoramas' in url:
        html = request.get_url(url)
        soup = BeautifulSoup(html, 'html.parser')
        url = soup.find("iframe").get("src") if soup.find("iframe").get("src") else False
        if url:
            if 'nyiabak.com' in url:
                url = url.replace("nyiabak.com", "fembed.com")
    return url