# -*- coding: utf-8 -*-
import sys
import os
import time
import json
import html
import calendar
import urllib.parse
import xml.etree.ElementTree as ET
import re
from datetime import datetime

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests

# =========================
# Configurações do Addon
# =========================
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_HANDLE = int(sys.argv[1])

USERNAME = ADDON.getSetting('username') or ''
PASSWORD = ADDON.getSetting('password') or ''
ENABLE_EPG = ADDON.getSetting('enable_epg') or 'false'
ENABLE_ADULT = ADDON.getSetting('enable_adult') or 'false'

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
HEADERS = {'User-Agent': USER_AGENT}

HOME = ADDON.getAddonInfo('path')
addonIcon = xbmcvfs.translatePath(os.path.join(HOME, 'icon.png'))

# =========================
# DNS hardcoded (substitui dns.json)
# =========================
DNS_LIST = [
    "http://beantec.ca",
    "http://egmr.ca",
    "http://cdn.club8.ca"
]

def get_base_url():
    """Retorna o DNS escolhido pelo usuário ou default (primeiro da lista)."""
    try:
        idx = int(ADDON.getSetting("server_choice") or "0")
    except Exception:
        idx = 0
    if idx < 0 or idx >= len(DNS_LIST):
        idx = 0
    return DNS_LIST[idx]

# =========================
# Profile e EPG
# =========================
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EPG_XML_PATH = os.path.join(PROFILE_DIR, 'epg.xml')
EPG_META_PATH = os.path.join(PROFILE_DIR, 'epg_meta.json')
EPG_TTL = 24 * 3600  # 24h
_EPG_PARSED = None

# =========================
# Descrições (cache)
# =========================
DESC_TTL = 7 * 24 * 3600  # 7 dias
VOD_DESC_CACHE_PATH = os.path.join(PROFILE_DIR, 'vod_desc_cache.json')
SERIES_DESC_CACHE_PATH = os.path.join(PROFILE_DIR, 'series_desc_cache.json')
_TAG_RE = re.compile(r'<[^>]+>')

# =========================
# Utilitários
# =========================
def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

def show_dialog(title, message):
    xbmcgui.Dialog().ok(title, message)

def build_url(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)

def ensure_profile_dir():
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdir(PROFILE_DIR)

def get_param_map():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        parsed = urllib.parse.urlparse(sys.argv[2])
        q = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        for k, v in q.items():
            params[k] = v[0] if isinstance(v, list) else v
    return params

def get_param(name, default=""):
    return PARAMS.get(name, default)

def fingerprint():
    BASE_URL = get_base_url()
    return f"{BASE_URL}|{USERNAME}|{PASSWORD}"

def safe_requests_get(url, **kw):
    kw.setdefault('headers', HEADERS)
    kw.setdefault('timeout', 30)

    retries = int(kw.pop('retries', 2))
    backoff = float(kw.pop('backoff', 1.0))
    last_exc = None
    for attempt in range(retries + 1):
        try:
            r = requests.get(url, **kw)
            if r.status_code == 429 and attempt < retries:
                time.sleep(backoff * (2 ** attempt))
                continue
            r.raise_for_status()
            return r
        except requests.RequestException as e:
            last_exc = e
            if isinstance(e, requests.HTTPError):
                resp = getattr(e, 'response', None)
                if resp is not None and resp.status_code == 429 and attempt < retries:
                    time.sleep(backoff * (2 ** attempt))
                    continue
            break
    raise last_exc if last_exc else requests.RequestException("Falha na requisição")

def get_json(endpoint):
    BASE_URL = get_base_url()
    if not all([BASE_URL, USERNAME, PASSWORD]):
        log("Credenciais incompletas.", xbmc.LOGERROR)
        show_dialog("Erro", "Configure host, usuário e senha nas configurações.")
        return None

    url = f"{BASE_URL.rstrip('/')}/player_api.php?username={USERNAME}&password={PASSWORD}&{endpoint}"
    log(f"API: {url}")

    try:
        r = safe_requests_get(url)
        return r.json()
    except requests.RequestException as e:
        log(f"Erro na requisição: {e}", xbmc.LOGERROR)
        show_dialog("Erro", f"Falha na API: {e}")
    except ValueError:
        log(f"Resposta inválida (não-JSON) da API: {url}", xbmc.LOGERROR)
        show_dialog("Erro", "Resposta da API não é JSON válido.")
    return None

# =========================
# Descrições (helpers + cache)
# =========================
def clean_plot(text):
    text = html.unescape(text or '')
    text = _TAG_RE.sub('', text)
    return text.strip()

def desc_cache_load(path):
    ensure_profile_dir()
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f) or {}
        except Exception:
            return {}
    return {}

def desc_cache_save(path, cache):
    try:
        ensure_profile_dir()
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Falha ao salvar cache de descrições: {e}", xbmc.LOGERROR)

def desc_cache_get(cache, key):
    k = str(key)
    e = cache.get(k)
    if not isinstance(e, dict):
        return (False, '')
    fetched_at = e.get('fetched_at', 0)
    if not fetched_at or (time.time() - fetched_at) > DESC_TTL:
        return (False, '')
    return (True, e.get('plot', '') or '')

def desc_cache_put(cache, key, plot):
    cache[str(key)] = {'plot': plot or '', 'fetched_at': time.time()}

def extract_vod_plot(vod_info_json):
    if not isinstance(vod_info_json, dict):
        return ''
    info = vod_info_json.get('info') or {}
    movie_data = vod_info_json.get('movie_data') or {}
    plot = (
        info.get('plot')
        or info.get('description')
        or movie_data.get('plot')
        or movie_data.get('description')
        or ''
    )
    return clean_plot(plot)

def extract_series_plot(series_info_json):
    if not isinstance(series_info_json, dict):
        return ''
    info = series_info_json.get('info') or {}
    plot = (
        info.get('plot')
        or info.get('description')
        or info.get('overview')
        or ''
    )
    return clean_plot(plot)

def get_vod_plot_cached(vod_id):
    cache = desc_cache_load(VOD_DESC_CACHE_PATH)
    has, plot = desc_cache_get(cache, vod_id)
    if has:
        return plot

    vod_info = get_json(f"action=get_vod_info&vod_id={vod_id}")
    plot = extract_vod_plot(vod_info)
    desc_cache_put(cache, vod_id, plot)
    desc_cache_save(VOD_DESC_CACHE_PATH, cache)
    return plot

def get_series_plot_cached(series_id):
    cache = desc_cache_load(SERIES_DESC_CACHE_PATH)
    has, plot = desc_cache_get(cache, series_id)
    if has:
        return plot

    series_info = get_json(f"action=get_series_info&series_id={series_id}")
    plot = extract_series_plot(series_info)
    desc_cache_put(cache, series_id, plot)
    desc_cache_save(SERIES_DESC_CACHE_PATH, cache)
    return plot

# =========================
# Play item
# =========================
def play_item(url, title, icon, normalplayer, vod_id=None, series_id=None):
    plot = ''
    try:
        if vod_id:
            plot = get_vod_plot_cached(vod_id) or ''
        elif series_id:
            plot = get_series_plot_cached(series_id) or ''
    except Exception as e:
        log(f"Falha ao obter sinopse no play: {e}", xbmc.LOGDEBUG)
        plot = ''

    if url and 'User-Agent=' not in url:
        url = url + '|User-Agent=' + USER_AGENT

    li = xbmcgui.ListItem(label=title, path=url)
    li.setArt({'icon': icon, 'thumb': icon})
    li.setInfo('video', {'title': title, 'plot': plot} if plot else {'title': title})

    if normalplayer == 'false':
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
    else:
        player = xbmc.Player()
        player.play(item=url, listitem=li)

# =========================
# Menu principal / modos
# =========================
def main():
    global PARAMS
    PARAMS = get_param_map()
    mode = get_param('mode', None)

    log(f"[VIP] Modo atual: {mode}")

    # 🔐 Garante login antes de qualquer coisa
    if not USERNAME or not PASSWORD:
        log("[VIP] Usuário ou senha ausentes, abrindo settings")
        ADDON.openSettings()
        return

    # 📌 Se não veio modo nenhum, abre o DASHBOARD VIP
    if not mode:
        vip_dashboard()
        return

    # 📊 Informações da conta
    if mode == 'account_info':
        info = get_account_info()
        if info:
            xbmcgui.Dialog().textviewer("Informações da Conta VIP", info)
        else:
            show_dialog("Erro", "Não foi possível obter informações da conta.")
        return

    # ⚙️ Configurações
    if mode == 'settings':
        ADDON.openSettings()
        return

    # 📺 TV ao vivo
    if mode == 'tv':
        build_menu(get_items('get_live_streams'), is_playable=True)
        return

    # 🎬 Filmes
    if mode == 'movies':
        build_menu(get_items('get_vod_streams'), is_playable=True)
        return

    # 📚 Séries
    if mode == 'series':
        build_menu(get_items('get_series'))
        return

    # ▶️ Play
    if mode == 'play':
        url = get_param('url')
        title = get_param('title', 'Reproduzindo')
        icon = get_param('icon', addonIcon)
        normalplayer = get_param('normalplayer', 'false')
        vod_id = get_param('vod_id') or None
        series_id = get_param('series_id') or None

        if not url:
            show_dialog("Erro", "URL inválida para reprodução.")
            return

        play_item(
            url=url,
            title=title,
            icon=icon,
            normalplayer=normalplayer,
            vod_id=vod_id,
            series_id=series_id
        )
        return

    # ❌ Fallback
    show_dialog("Erro", f"Modo VIP desconhecido: {mode}")
